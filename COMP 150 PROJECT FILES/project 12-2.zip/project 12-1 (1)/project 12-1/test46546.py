pip install simpleaudio
