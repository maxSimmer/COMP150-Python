'''Input three numbers, then list all three and the sum.'''

x=int(input('Enter a number: '))
y=int(input('Enter a second number: '))
z=int(input('Enter a third number: '))
sum = x+y+z
print('The sum of ', x, ' and ', y, ' and ', z, ' is ', sum, '.', sep='')
