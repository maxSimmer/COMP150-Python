def yummyThings():
    yummyThings = dict()
    yummyThings['Food'] = 'Pizza'
    yummyThings['Drink'] = 'Sprite'

def runyummyThings():
    dictionary = yummyThings()
    print(dictionary['Food'])

runyummyThings()





