'''Where Did Summer Go?'''

#Oh, my God, I feel it in the air
#Telephone wires above are sizzlin' like a snare
#Honey, I'm on fire, I feel it everywhere
#Nothin' scares me anymore
#Lana Del Rey - Summertime Sadness

def verse1():
    print('Oh, my God, I feel it in the air')
    print('Telephone wires above are sizzlin\' like a snare')
    print('Honey, I\'m on fire, I feelt it everywhere')
    print('Nothin\' scares me anymore')

def main():
    verse1()
    verse1()
    verse1()

main()
