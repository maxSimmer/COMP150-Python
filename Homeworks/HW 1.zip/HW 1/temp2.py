'''Someone is a homo'''

x = input('Enter a name: ')

